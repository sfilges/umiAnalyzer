#' UMIexperiment data generated with SiMSen-Seq
#'
#' @docType data
#'
#' @usage data(simsen)
#'
#' @format Anobject of class \code{"UMIexperiment"}
#'
#' @keywords datasets
#'
"simsen"
